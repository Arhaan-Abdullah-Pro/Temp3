import streamlit as st
import pandas as pd
from langchain_google_genai import ChatGoogleGenerativeAI, GoogleGenerativeAIEmbeddings
from langchain.vectorstores import FAISS
from langchain.text_splitter import CharacterTextSplitter
from langchain.chains import RetrievalQA
from langchain_core.documents import Document
from dotenv import load_dotenv

load_dotenv()
# Load & merge CSVs
def merge_csv(f1, f2):
    df1 = pd.read_csv(f1)
    df2 = pd.read_csv(f2)
    merge_df = pd.merge(df1,df2, on="eqID", how="inner")
    date_columns = ["failed_date", "report_date", "rectified_date"]
    for col in date_columns:
        if col in merge_df.columns:
            merge_df[col] = pd.to_datetime(merge_df[col], errors="coerce")
    return merge_df


#convert dataframe into Langchain Docs
def df_to_docs(df):
    docs=[]
    for idx, row in df.iterrows():
        text = "\n".join(f"{col} : {val}" for col, val in row.items())
        docs.append(Document(page_content=text, metadata={"source": f"row_{idx}"}))
    return docs
# Build vector store (FAISS)
def build_vector_store(docs):
    splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
    chunks = splitter.split_documents(docs)
    embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001")
    vectorstore = FAISS.from_documents(chunks, embeddings)
    return vectorstore

def build_rag_chain(vectorstore):
    retriever = vectorstore.as_retriever()
    llm = ChatGoogleGenerativeAI(model="gemini-1.5-flash-latest", temperature=0.6)
    qa_chain = RetrievalQA.from_chain_type(llm=llm, retriever=retriever)
    return qa_chain

# Streamlit UI
st.title("📊 Gemini-Powered Equipment Q&A (RAG)")

uploaded_files = st.file_uploader("Upload two related CSVs (e.g. equipment + failure)", type="csv", accept_multiple_files=True)

if uploaded_files and len(uploaded_files) == 2:
    df = merge_csv(uploaded_files[0], uploaded_files[1])

    st.subheader("📋 Preview of Merged Data")
    st.dataframe(df)

    docs = df_to_docs(df)
    vectorstore = build_vector_store(docs)
    qa_chain = build_rag_chain(vectorstore)

    question = st.text_input("Ask your question (e.g. What equipment failed in April?)")

    if question:
        with st.spinner("Searching with RAG..."):
            answer = qa_chain.run(question)
            st.markdown("### ✅ Answer:")
            st.write(answer)
else:
    st.info("Please upload exactly two CSV files.")

