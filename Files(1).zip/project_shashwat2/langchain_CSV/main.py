import streamlit as st
import pandas as pd
from langchain_experimental.agents import create_csv_agent
from langchain_google_genai import ChatGoogleGenerativeAI
from dotenv import load_dotenv
import io

def merge_csv(f1, f2):
    df1 = pd.read_csv(f1)
    df2 = pd.read_csv(f2)
    merge_df = pd.merge(df1,df2, on="eqID", how="inner")
    csv_buffer = io.StringIO()
    merge_df.to_csv(csv_buffer, index=False)
    csv_buffer.seek(0)
    return csv_buffer
    
def main():
    load_dotenv()


    st.set_page_config(page_title="Ask your CSV")
    st.header("Telemetry Assistant")

    user_csv = st.file_uploader("Upload your CSV file", type="csv", accept_multiple_files=True)
    

    if user_csv is not None:
        question = st.text_input("Ask a question about your CSV")

        llm = ChatGoogleGenerativeAI(
            model="gemini-1.5-flash-latest",
            temperature=0.3
        )
        agent = create_csv_agent(llm, user_csv, verbose=False, allow_dangerous_code=True)

        if question is not None and question != "":
            st.spinner("Going through files")
            response = agent.run(question)
            st.write(response)

if __name__ == "__main__":
    main()