# Predictive Maintenance – LLM Assistant (LangChain + Ollama)

This Streamlit app integrates your **trained failure prediction model** with a **local LLM** via LangChain + Ollama. Users can ask questions like:

> "What is the failure probability for machine 12 in the next 30 days?"

and get a conversational answer plus the underlying prediction.

## Structure

- Loads datasets from your repo: `final_project/PredictiveMaintenance-main/Datasets/*`
- Loads a trained model from: `final_project/PredictiveMaintenance-main/models/catBoost.pkl` (or fallback to other pickles in that folder)
- Talks to a local Ollama server (`http://localhost:11434`) with a configurable model (default `llama3:8b`)

## Setup

1. Install dependencies
   ```bash
   pip install -r requirements.txt
   ```

2. Make sure Ollama is installed and running, and pull a model (example):
   ```bash
   ollama serve
   ollama pull llama3:8b
   ```

3. Make sure your trained model pickle exists at:
   ```
   final_project/PredictiveMaintenance-main/models/catBoost.pkl
   ```
   (or place another trained model file there; the app will try common filenames.)

4. Run the app
   ```bash
   streamlit run app.py
   ```

## Notes

- The app builds a **lightweight feature snapshot** (last 24h aggregates + machine meta) and attempts to **align features** to the trained model automatically.
- If your training used different engineered features, export and reuse the exact preprocessing or alter `build_feature_snapshot()` and `align_features_to_model()` accordingly.
- You can change the Ollama model in the sidebar.