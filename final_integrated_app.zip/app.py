
import os
import re
import json
import time
import math
import joblib
import pandas as pd
import numpy as np
import streamlit as st

# LangChain / Ollama
from langchain_community.llms import Ollama
from langchain_core.prompts import ChatPromptTemplate

############################
# Paths & Config
############################
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__)))
PDM_DIR = os.path.abspath(os.path.join(BASE_DIR, "..", "project_files", "project_shashwat2", "final_project", "PredictiveMaintenance-main"))
DATA_DIR = os.path.join(PDM_DIR, "Datasets")
MODELS_DIR = os.path.join(PDM_DIR, "models")

DEFAULT_OLLAMA_MODEL = st.secrets.get("OLLAMA_MODEL", "llama3:8b")
OLLAMA_BASE_URL = st.secrets.get("OLLAMA_BASE_URL", "http://localhost:11434")

st.set_page_config(page_title="Predictive Maintenance – LLM Assistant", layout="wide")
st.title("🔧 Predictive Maintenance – LLM Assistant (LangChain + Ollama)")

st.caption("This app lets you ask natural-language questions and get failure probability predictions powered by your trained model.")

############################
# Utilities
############################
@st.cache_resource(show_spinner=False)
def load_model():
    candidates = [
        os.path.join(MODELS_DIR, "catBoost.pkl"),
        os.path.join(MODELS_DIR, "ensemble_model.pkl"),
        os.path.join(MODELS_DIR, "rf_model.pkl"),
        os.path.join(MODELS_DIR, "svc_pipeline.pkl"),
        os.path.join(MODELS_DIR, "logreg_model.pkl"),
    ]
    for p in candidates:
        if os.path.exists(p):
            try:
                m = joblib.load(p)
                return m, os.path.basename(p)
            except Exception as e:
                pass
    return None, None

@st.cache_resource(show_spinner=False)
def load_datasets():
    files = {
        "telemetry": os.path.join(DATA_DIR, "PdM_telemetry.csv"),
        "failures": os.path.join(DATA_DIR, "PdM_failures.csv"),
        "machines": os.path.join(DATA_DIR, "PdM_machines.csv"),
        "maint": os.path.join(DATA_DIR, "PdM_maint.csv"),
    }
    dfs = {}
    for k, p in files.items():
        if os.path.exists(p):
            df = pd.read_csv(p)
            dfs[k] = df
    return dfs

def build_feature_snapshot(dfs, machine_id: int):
    """
    A light feature builder that summarizes latest telemetry state for a machine.
    This may differ from your training-time engineering, but we attempt to align columns dynamically.
    """
    if "telemetry" not in dfs or "machines" not in dfs:
        return None, "Missing telemetry or machines dataset."
    tel = dfs["telemetry"].copy()
    mac = dfs["machines"].copy()

    tel["datetime"] = pd.to_datetime(tel["datetime"])
    tel = tel.sort_values(["machineID", "datetime"])

    # last 24h window relative to last timestamp for that machine
    t_last = tel.loc[tel["machineID"] == machine_id, "datetime"].max()
    if pd.isna(t_last):
        return None, f"No telemetry for machine {machine_id}."
    window_start = t_last - pd.Timedelta(hours=24)

    sub = tel[(tel["machineID"] == machine_id) & (tel["datetime"] >= window_start) & (tel["datetime"] <= t_last)].copy()
    if sub.empty:
        sub = tel[tel["machineID"] == machine_id].tail(24).copy()

    # aggregate simple stats
    agg = sub.agg({
        "volt": ["mean","std","min","max","last"],
        "rotate": ["mean","std","min","max","last"],
        "pressure": ["mean","std","min","max","last"],
        "vibration": ["mean","std","min","max","last"],
    })
    agg.columns = ["_".join([c[0], c[1]]) for c in agg.columns.to_flat_index()]
    features = agg.to_dict()
    # flatten single row
    features = {k: float(v) for k,v in features.items()}

    # machine meta
    row = mac.loc[mac["machineID"] == machine_id].head(1)
    if not row.empty:
        features["machineID"] = int(machine_id)
        features["age"] = float(row["age"].iloc[0])
        # one-hot model label if present
        features["model"] = str(row["model"].iloc[0])
    else:
        features["machineID"] = int(machine_id)

    feat_df = pd.DataFrame([features])

    # simple one-hot on model (only if small cardinality)
    if "model" in feat_df.columns:
        feat_df = pd.get_dummies(feat_df, columns=["model"], prefix="model")

    return feat_df, None

def align_features_to_model(X: pd.DataFrame, model):
    """
    Try to align columns to what the model expects.
    """
    # scikit models may provide feature_names_in_
    cols = None
    if hasattr(model, "feature_names_in_"):
        cols = list(model.feature_names_in_)
    elif hasattr(model, "feature_names_"):
        cols = list(getattr(model, "feature_names_"))
    # If we know expected cols, fill missing with zeros and reorder
    if cols:
        for c in cols:
            if c not in X.columns:
                X[c] = 0.0
        X = X[cols]
    else:
        # best effort: keep numeric columns only
        X = X.select_dtypes(include=[np.number])
    return X

def predict_failure_probability(model, X):
    try:
        if hasattr(model, "predict_proba"):
            proba = model.predict_proba(X)
            # assume binary classification, take failure prob = class 1
            if proba.ndim == 2 and proba.shape[1] >= 2:
                return float(proba[0, 1])
            else:
                return float(proba[0])
        else:
            # decision_function or raw score
            pred = model.predict(X)
            return float(pred[0])
    except Exception as e:
        raise

############################
# LLM wiring
############################
@st.cache_resource(show_spinner=False)
def get_llm():
    return Ollama(model=DEFAULT_OLLAMA_MODEL, base_url=OLLAMA_BASE_URL, temperature=0.1)

INTENT_PROMPT = ChatPromptTemplate.from_template(
    """You are an intent classifier for a predictive maintenance assistant.
Return a compact JSON with fields:
- intent: one of ["predict", "describe", "data"]
- machine_id: integer if present else null
- horizon_days: integer if present else null
- question: the original question

Examples:
User: "probability that machine 12 fails in next 30 days"
JSON: {"intent":"predict","machine_id":12,"horizon_days":30,"question":"probability that machine 12 fails in next 30 days"}

User: "show me details of equipment 5"
JSON: {"intent":"describe","machine_id":5,"horizon_days":null,"question":"show me details of equipment 5"}

User: "which machines had most failures in April"
JSON: {"intent":"data","machine_id":null,"horizon_days":null,"question":"which machines had most failures in April"}

Only output JSON. No extra text.
User: {user_q}
"""
)

def parse_intent(llm, user_q: str):
    try:
        prompt = INTENT_PROMPT.format(user_q=user_q)
        raw = llm.invoke(prompt)
        # Some Ollama models return dict-like; ensure str -> json
        if isinstance(raw, dict):
            return raw
        j = re.search(r"\{[\s\S]*\}", str(raw))
        data = json.loads(j.group(0)) if j else {}
        return data
    except Exception:
        # Fallback: simple regex extraction
        mid = re.search(r"machine\s*#?\s*(\d+)|\beq(?:uip)?(?:ID)?\s*(\d+)", user_q, re.I)
        days = re.search(r"next\s*(\d+)\s*days|in\s*(\d+)\s*days", user_q, re.I)
        machine_id = int(next((g for g in (mid.group(1) if mid else None, mid.group(2) if mid else None) if g), 0)) if mid else None
        horizon = int(days.group(1) or days.group(2)) if days else None
        return {"intent": "predict" if (machine_id and horizon) else "data", "machine_id": machine_id, "horizon_days": horizon, "question": user_q}

############################
# Sidebar Config
############################
with st.sidebar:
    st.header("⚙️ Settings")
    model_obj, model_name = load_model()
    if model_obj is None:
        st.error("No trained model found in /models. Place your trained pickle (e.g., catBoost.pkl) under:\n" + MODELS_DIR)
    else:
        st.success(f"Loaded model: {model_name}")
    dfs = load_datasets()
    if not dfs:
        st.error("Datasets not found under Datasets/.")
    else:
        st.caption("Datasets loaded: " + ", ".join(sorted(dfs.keys())))
    DEFAULT_OLLAMA_MODEL = st.text_input("Ollama model name", value=DEFAULT_OLLAMA_MODEL, help="e.g., llama3:8b, mistral, qwen2, etc.")
    st.caption(f"Ollama base URL: {OLLAMA_BASE_URL}")

############################
# Main Chat UI
############################
st.subheader("💬 Ask a question")
user_q = st.text_input("Type your question (e.g., 'What is the failure probability for machine 12 in the next 30 days?')")

if "history" not in st.session_state:
    st.session_state.history = []

if st.button("Ask", type="primary") and user_q:
    llm = get_llm()
    intent = parse_intent(llm, user_q)
    st.session_state.history.append(("user", user_q))

    # default response blocks
    answer_blocks = []

    if intent.get("intent") == "predict" and intent.get("machine_id"):
        mid = int(intent["machine_id"])
        horizon = intent.get("horizon_days") or 30
        # build features
        X, err = build_feature_snapshot(dfs, mid)
        if err:
            answer_blocks.append(f"I couldn't prepare features for machine {mid}: {err}")
        elif model_obj is None:
            answer_blocks.append("Model not available on server.")
        else:
            X_aligned = align_features_to_model(X, model_obj)
            try:
                prob = predict_failure_probability(model_obj, X_aligned)
                # Let LLM verbalize result
                verbal_prompt = f"""You are a maintenance analyst. In 3-5 sentences, explain the estimated probability of failure.
Context:
- Machine ID: {mid}
- Horizon: {horizon} days
- Estimated probability of failure: {prob:.3f} (0 to 1 scale)
- Latest features used: {list(X_aligned.columns)[:8]} ...

Write a concise, plain-English recommendation including one preventive action.
"""
                verbal = llm.invoke(verbal_prompt)
                answer_blocks.append(str(verbal))
            except Exception as e:
                answer_blocks.append(f"Prediction failed due to feature mismatch or model error: {e}")
    elif intent.get("intent") == "describe" and intent.get("machine_id"):
        mid = int(intent["machine_id"])
        # show last snapshot
        tel = dfs.get("telemetry")
        mac = dfs.get("machines")
        if tel is not None and mac is not None:
            last = tel[tel["machineID"] == mid].sort_values("datetime").tail(1)
            meta = mac[mac["machineID"] == mid].head(1)
            if not last.empty and not meta.empty:
                d = last.iloc[0].to_dict()
                d.update({f"machine_{k}": v for k,v in meta.iloc[0].to_dict().items()})
                verbal_prompt = f"Summarize this machine in 3-4 sentences for a maintenance manager: {json.dumps(d)}"
                verbal = llm.invoke(verbal_prompt)
                answer_blocks.append(str(verbal))
            else:
                answer_blocks.append(f"No records for machine {mid}.")
        else:
            answer_blocks.append("Datasets not loaded.")
    else:
        # Generic data/RAG style answer: simple descriptive insight
        # We will compute top failing machines historically and let LLM summarize.
        fails = dfs.get("failures")
        if fails is not None:
            fails["datetime"] = pd.to_datetime(fails["datetime"])
            top = fails.groupby("machineID").size().sort_values(ascending=False).head(10).reset_index(name="fail_count")
            context = top.to_dict(orient="records")
            verbal_prompt = f"""User question: {user_q}
Use the context below to answer succinctly. If needed, cite machine IDs explicitly.
Context (top failing machines historically): {json.dumps(context)}
If insufficient, say what else you need from the user in one sentence.
"""
            verbal = llm.invoke(verbal_prompt)
            answer_blocks.append(str(verbal))
        else:
            answer_blocks.append("I couldn't access the failures dataset to answer that. Try a prediction query (machine id + horizon).")


    st.session_state.history.append(("assistant", "\n\n".join(answer_blocks)))

# Render chat
for role, msg in st.session_state.history[-10:]:
    if role == "user":
        st.markdown(f"**You:** {msg}")
    else:
        st.markdown(f"**Assistant:** {msg}")

st.divider()
st.markdown("#### 📎 Notes")
st.markdown("- This app attempts to align features to the trained model automatically; if your training used custom engineered columns, keep your training-time preprocessing consistent and consider exporting the exact feature list alongside the model.")
st.markdown("- Ollama must be running locally with the selected model pulled (e.g., `ollama pull llama3:8b`).")
